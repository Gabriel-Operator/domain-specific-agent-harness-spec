---
name: verify-signals
description: Preserve evidence when reviewing a public signal.
---
Report what the evidence supports. Include its source URL when supplied.
