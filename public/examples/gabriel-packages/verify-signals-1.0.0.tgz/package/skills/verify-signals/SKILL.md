---
name: verify-signals
description: Verify signals and return a brief.
---
Use the evidence supplied with the goal.
